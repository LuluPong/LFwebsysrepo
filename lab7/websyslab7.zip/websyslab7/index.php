<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="assets\style.css">
</head>
<body>
<h2>The Gradebook</h2>
<div class="container">
  <div class="column">
    <a href="add_columns.php">
    <button type="button" class="btn btn-primary" value="add_column">Add Categories to Table</button>
    </a>
    <br>
    <a href="insert_values.php">
    <button type="button" class="btn btn-primary" value="insert">Insert Values into Table</button>
    </a>
    <br>
    <a href="add_grades.php">
    <button type="button" class="btn btn-primary" value="add_grade">Add Grades</button>
    </a>
    </div>
    <br>
    <a href="list_students.php">
    <button type="button" class="btn btn-primary" value="list_stu">List All Students</button>
    </a>
    <br>
    <a href="list_based_grade.php">
    <button type="button" class="btn btn-primary" value="list_stuG">List Students Based on Grade</button>
    </a>
    <br>
    <a href="list_avg.php">
      <button type="button" class="btn btn-primary" value="list_avg">List Average Grade per Course</button>
    </a>
    <br>
    <a href="list_count.php">
    <button type="button" class="btn btn-primary" value="list_count">List Number of Students in Course</button>
    </a>
</div>
</body>