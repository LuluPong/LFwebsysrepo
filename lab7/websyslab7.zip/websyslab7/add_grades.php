<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="assets\style.css">
</head>
<body>
<div class="container">
<form class="card" action="add_grades.php" method="GET">
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
        <div class="input-group-text">RIN</div>
        </div>
    <input type="text" class="form-control" name="RIN" id="rin" placeholder="Enter a RIN for a student (STUDENT MUST BE IN GRADEBOOK BEFORE ADDING GRADE)">
    </div>
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
        <div class="input-group-text">CRN</div>
        </div>
    <input type="text" class="form-control" name="CRN" id="crn" placeholder="Enter a CRN for a course (COURSE MUST BE IN GRADEBOOK BEFORE ADDING GRADE)">
    </div>
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
        <div class="input-group-text">GRADE</div>
        </div>
    <input type="text" class="form-control" name="grade" id="grade" placeholder="Enter a number">
    </div>
    <button type="submit" class="btn btn-primary mb-2">Submit</button>
</form>

<?php
if (!empty($_GET['CRN']) && !empty($_GET['RIN']) && !empty($_GET['grade'])){
    $crn = $_GET['CRN'];
    $rin = $_GET['RIN'];
    $grade = $_GET['grade'];

    $servername = "localhost";
    $username = "root";
    $password = "abcd";

    try {
    $conn = new PDO("mysql:host=$servername;dbname=websyslab7", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $stmt = $conn->prepare("INSERT INTO `grades`(`crn`, `RIN`, `grade`) VALUES ($crn,$rin,$grade)");
    $stmt->execute();

    echo "<h2>SUCCESS!</h2>";
    } catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    }

} else {
    echo "<h2>PLEASE ENTER VALID GRADES, CRNS, RINS</h2>";
}

?>

</div>
</body>