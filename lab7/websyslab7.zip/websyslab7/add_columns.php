<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="assets\style.css">
</head>
<body>
<div class="container">
<form class="card col-sm-5" action="add_columns.php" method="GET">
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
        <div class="input-group-text">Category Name</div>
        </div>
    <input type="text" class="form-control" name="categ_name" id="categ_name" placeholder="Enter Here">
    </div>
    <legend>Type</legend>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="type" id="integ" value="int">
        <label class="form-check-label" for="type">Integer</label>
    </div>
    <div class=form-check>
        <input class="form-check-input" type="radio" name="type" id="varchar" value="varchar">
        <label class="form-check-label" for="type">Varchar</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="type" id="char" value="char">
        <label class="form-check-label" for="type">Char</label>
    </div>

    <legend>Table Name</legend>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="table" id="t_stu" value="students">
        <label class="form-check-label" for="table">Students</label>
    </div>
    <div class=form-check>
        <input class="form-check-input" type="radio" name="table" id="t_course" value="courses">
        <label class="form-check-label" for="table">Courses</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="table" id="t_grade" value="grades">
        <label class="form-check-label" for="table">Grades</label>
    </div>
    <button type="submit" class="btn btn-primary mb-2">Submit</button>
</form>

<?php


if (!empty($_GET['categ_name']) && !empty($_GET['type']) && !empty($_GET['table'])){
    $categ = $_GET['categ_name'];
    $type = $_GET['type'];
    $table = $_GET['table'];

    $servername = "localhost";
    $username = "root";
    $password = "abcd";

    try {
    $conn = new PDO("mysql:host=$servername;dbname=websyslab7", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if ($type == 'varchar' || $type == 'char') {
    $stmt = $conn->prepare("ALTER TABLE $table ADD COLUMN $categ $type(255)");
    $stmt->execute();

    } else {
    $stmt = $conn->prepare("ALTER TABLE $table ADD COLUMN $categ $type");
    $stmt->execute();
    }

    echo "<h2>SUCCESS!</h2>";
    } catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    }

} else {
    echo "<h2>PLEASE ENTER VALID CATEGORY NAMES, TYPES, AND TABLES</h2>";
}

?>

</div>
</body>