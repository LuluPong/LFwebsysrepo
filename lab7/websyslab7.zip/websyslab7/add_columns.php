<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="assets\style.css">
</head>
<body>
<div class="container">
<form class="card col-sm-5" action="add_columns.php" method="GET">
    <div class="input-group mb-2 mr-sm-2">
        <div class="input-group-prepend">
        <div class="input-group-text">Category Name</div>
    </div>
    <input type="text" class="form-control" name="categ_name" id="categ_name" placeholder="Enter Here">
  </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="integ" id="integ" value="integ">
        <label class="form-check-label" for="integ">Integer</label>
    </div>
    <div class=form-check>
        <input class="form-check-input" type="radio" name="varchar" id="varchar" value="varchar">
        <label class="form-check-label" for="varchar">Varchar</label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" name="char" id="char" value="char">
        <label class="form-check-label" for="char">Char</label>
    </div>
    <button type="submit" class="btn btn-primary mb-2">Submit</button>
</form>
<?php
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>RIN</th><th>First name</th><th>Last name</th></tr>";

class TableRows extends RecursiveIteratorIterator {
   function __construct($it) {
       parent::__construct($it, self::LEAVES_ONLY);
   }

   function current() {
       return "<td class='table-dark' style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
   }

   function beginChildren() {
       echo "<tr>";
   }

   function endChildren() {
       echo "</tr>" . "\n";
   }
}

$servername = "localhost";
$username = "root";
$password = "abcd";

try {
  $conn = new PDO("mysql:host=$servername;dbname=websyslab7", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
  $stmt = $conn->prepare("SELECT * FROM students;");
  $stmt->execute();

  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }

} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}


echo "</table>";
?>
</div>
</body>