<!DOCTYPE html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" href="assets\style.css">
</head>
<body>
<?php
echo "<table class='table' style='border: solid 1px black;'>";
echo "<tr><th>Course Title</th><th>CRN</th><th>Number of Students</th></tr>";

class TableRows extends RecursiveIteratorIterator {
   function __construct($it) {
       parent::__construct($it, self::LEAVES_ONLY);
   }

   function current() {
       return "<td class='table-dark' style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
   }

   function beginChildren() {
       echo "<tr>";
   }

   function endChildren() {
       echo "</tr>" . "\n";
   }
}

$servername = "localhost";
$username = "root";
$password = "abcd";

try {
  $conn = new PDO("mysql:host=$servername;dbname=websyslab7", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Connected successfully";
  $stmt = $conn->prepare("SELECT courses.title, grades.crn, COUNT(grades.RIN) AS Number_of_Students_in_Class FROM grades INNER JOIN courses ON grades.crn = courses.crn GROUP BY courses.title;");
  $stmt->execute();

  $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }

} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}


echo "</table>";
?>
</body>