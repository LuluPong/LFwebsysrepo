<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    </head>
<body>
    <div class="container card w-25 mt-5">
    <h2>Calculator Web Applicaton</h2>
        <form action="testcalc.php" method="GET" class="mt-3">
            <div class="form-group m-3">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-sm">First Number</span>
                    </div>
                    <input name="first_num" id="first_num" class="form-control" type="number" aria-label="Small" aria-describedby="inputGroup-sizing-sm" step=any>
                </div>
                <br>
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-sm">Second Number (optional)</span>
                    </div>
                    <input name="second_num" id="second_num" class="form-control" type="number" aria-label="Small" aria-describedby="inputGroup-sizing-sm" step=any>
                </div>
            </div>
            <label for="operation">Operations</label>
            <select name="operation" id="operation" class="custom-select m-2">
                <option value="x+">Add</option>
                <option value="x-">Subtract</option>
                <option value="multi">Multiply</option>
                <option value="divide">Divide</option>
                <option value="x**y">x&#x1D57</option>
                <option value="x**2">x&#178</option>
                <option value="sqrt">&#8730;x</option>
                <option value="reglog">Log(10)</option>
                <option value="nattylog">Ln</option>
                <option value="10**x">10&#x1D57</option>
                <option value="e**x">e&#x1D57</option>
                <option value="sin">Sin</option>
                <option value="cos">Cos</option>
                <option value="tan">Tan</option>
            </select>
            <br>
            <button name="submit" type="submit" class="btn btn-danger">Submit</button>
            <br>
            <br>
        </form>
    </div>  
</body>
</html>