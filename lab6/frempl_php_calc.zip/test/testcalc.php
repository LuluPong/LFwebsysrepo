<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
    </head>
<body>
    <?php

        interface Calculation {
            public function calculate();
        }

        class powerTwo implements Calculation {
            private $number;

            public function __construct($number){
                $this->number = $number;
            }

            public function calculate(){
                return pow($this->number, 2);
            }
        }

        class squareRoot implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate(){
                return sqrt($this->number);
            }
        }

        class TenbyX implements Calculation {
            private $number;

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return pow(10, $this->number);
            }
        }

        class ebyX implements Calculation {
            private $number;

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return exp($this->number);
            }

        }

        class naturalLog implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return log($this->number);
            }
        }

        class logTen implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return log10($this->number);
            }
        }

        class Sin implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return sin($this->number);
            }
        }

        class Cos implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return cos($this->number);
            }
        }

        class Tan implements Calculation {
            private $number; 

            public function __construct($number) {
                $this->number = $number;
            }

            public function calculate() {
                return tan($this->number);
            }
        }

        class Addition implements Calculation {
            private $number_one;
            private $number_two; 

            public function __construct($number_one, $number_two) {
                $this->number_one = $number_one;
                $this->number_two = $number_two;
            }

            public function calculate() {
                return $this->number_one + $this->number_two;
            }
        }

        class Subtraction implements Calculation {
            private $number_one;
            private $number_two; 

            public function __construct($number_one, $number_two) {
                $this->number_one = $number_one;
                $this->number_two = $number_two;
            }

            public function calculate() {
                return $this->number_one - $this->number_two;
            }
        }

        class Multiplication implements Calculation {
            private $number_one;
            private $number_two; 

            public function __construct($number_one, $number_two) {
                $this->number_one = $number_one;
                $this->number_two = $number_two;
            }

            public function calculate() {
                return $this->number_one * $this->number_two;
            }
        }

        class Division implements Calculation {
            private $number_one;
            private $number_two; 

            public function __construct($number_one, $number_two) {
                $this->number_one = $number_one;
                $this->number_two = $number_two;
            }

            public function calculate() {
                return $this->number_one/$this->number_two;
            }
        }

        class ExbyY implements Calculation {
            private $number_one;
            private $number_two; 

            public function __construct($number_one, $number_two) {
                $this->number_one = $number_one;
                $this->number_two = $number_two;
            }

            public function calculate() {
                return $this->number_one ** $this->number_two;
            }
        }
     
        

        if ($_GET["first_num"]) {
            echo "<p class=container>" . "Result: " . "</p><br>";
            switch ($_GET["operation"]) {
                case "x**2":
                    $squared = new powerTwo($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $squared->calculate() . "</p>";
                    break;
                case "sqrt":
                    $rooted = new squareRoot($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $rooted->calculate() . "</p>";
                    break;
                case "reglog":
                    $logby10 = new logTen($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $logby10->calculate() . "</p>";
                    break;
                case "nattylog":
                    $natlog = new naturalLog($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $natlog->calculate() . "</p>";
                    break;
                case "10**x":
                    $tenex = new TenbyX($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $tenex->calculate() . "</p>";
                    break;
                case "e**x":
                    $ex = new ebyX($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $ex->calculate() . "</p>";
                    break;
                case "sin":
                    $sin_number = new Sin($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $sin_number->calculate() . "</p>";
                    break;
                case "cos":
                    $cos_number = new Cos($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $cos_number->calculate() . "</p>";
                    break;
                case "tan":
                    $tan_number = new Tan($_GET["first_num"]);
                    echo "<br><br><p class=container>" . $tan_number->calculate() . "</p>";
                    break;
                case "x+":
                    $add = new Addition($_GET["first_num"], $_GET["second_num"]);
                    echo "<br><br><p class=container>" . $add->calculate() . "</p>";
                    break;
                case "x-":
                    $subtract = new Subtraction($_GET["first_num"], $_GET["second_num"]);
                    echo "<br><br><p class=container>" . $subtract->calculate() . "</p>";
                    break;
                case "multi":
                    $multiply = new Multiplication($_GET["first_num"], $_GET["second_num"]);
                    echo "<br><br><p class=container>" . $multiply->calculate() . "</p>";
                    break;
                case "divide":
                    $divide = new Division($_GET["first_num"], $_GET["second_num"]);
                    echo "<br><br><p class=container>" . $divide->calculate() . "</p>";
                    break;
                case "x**y":
                    $xbyY = new ExbyY($_GET["first_num"], $_GET["second_num"]);
                    echo "<br><br><p class=container>" . $xbyY->calculate() . "</p>";
                    break;
            }
        
        } 

        if (!$_GET) echo "GO BACK AND ENTER A VALID NUMBER"

        ?>

        <div class="container card w-25 mt-5">
            <h2>Calculator Web Applicaton</h2>
                <form action="testcalc.php" method="GET" class="mt-3">
                    <div class="form-group m-3">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm">First Number</span>
                            </div>
                            <input name="first_num" id="first_num" class="form-control" type="number" aria-label="Small" aria-describedby="inputGroup-sizing-sm" step=any>
                        </div>
                        <br>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="inputGroup-sizing-sm">Second Number (optional)</span>
                            </div>
                            <input name="second_num" id="second_num" class="form-control" type="number" aria-label="Small" aria-describedby="inputGroup-sizing-sm" step=any>
                        </div>
                    </div>
                    <label for="operation">Operations</label>
                    <select name="operation" id="operation" class="custom-select m-2">
                        <option value="x+">Add</option>
                        <option value="x-">Subtract</option>
                        <option value="multi">Multiply</option>
                        <option value="divide">Divide</option>
                        <option value="x**y">x&#x1D57</option>
                        <option value="x**2">x&#178</option>
                        <option value="sqrt">&#8730;x</option>
                        <option value="reglog">Log(10)</option>
                        <option value="nattylog">Ln</option>
                        <option value="10**x">10&#x1D57</option>
                        <option value="e**x">e&#x1D57</option>
                        <option value="sin">Sin</option>
                        <option value="cos">Cos</option>
                        <option value="tan">Tan</option>
                    </select>
                    <br>
                    <button name="submit" type="submit" class="btn btn-danger">Submit</button>
                    <br>
                    <br>
                </form>
            </div>  
</body>